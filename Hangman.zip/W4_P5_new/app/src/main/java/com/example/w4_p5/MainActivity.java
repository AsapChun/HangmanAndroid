package com.example.w4_p5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Parcelable;
import android.os.Parcel;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //we only create one answer for this game which is "quizlet"
    private Button btnHint;
    private TextView lblHint;
    private ImageView imgViewResult;
    final String answer = "QUIZLET";

    //btns for buttons from A to Z
    private Button[] btns = new Button[26];
    public int hintCount = 0;
    private gameRun game;

    //txtAnswers for answers' textviews
    private TextView[] txtAnswers = new TextView[7];
    private Button btnReset;
    private boolean result = false;


    public void doHint(){
        if(hintCount == 1) { //The first time it is clicked it displays a hint message BUT it costs the user a turn

            changeImg(game);
            lblHint.setText("Hint: Study Tool");
        }

        else if(hintCount == 2){
            //The second time it is clicked it disables half of the remaining letters (that are not
            //part of the word) BUT it costs the user a turn.
            lblHint.setText("Hint: Study Tool");
            changeImg(game);
            int disableBtnCount = 0;
            for(int i=0; i<btns.length;i++){
                boolean found = false;
                //String word = game.getWord();
                String theAnswer = answer;
                String theLetter = btns[i].getText().toString();
                if(answer.contains(btns[i].getText().toString())){
                    continue;
                }
                else{
                    btns[i].setClickable(false);
                    disableBtnCount++;
                }
                if(disableBtnCount >= btns.length/2){
                    break;
                }
            }
        }
        else if (hintCount == 3){ //do nothing
            btnHint.setClickable(false);
            lblHint.setText("Hint: Study Tool");
            changeImg(game);
            int disableBtnCount = 0;
            for(int i=0; i<btns.length;i++){
                boolean found = false;
                //String word = game.getWord();
                String theAnswer = answer;
                String theLetter = btns[i].getText().toString();
                if(answer.contains(btns[i].getText().toString())){
                    continue;
                }
                else{
                    btns[i].setClickable(false);
                    disableBtnCount++;
                }
                if(disableBtnCount >= btns.length/2){
                    break;
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create new game
        game = new gameRun();

        //bind everything here
        btns[0] = findViewById(R.id.btnA);
        btns[1] = findViewById(R.id.btnB);
        btns[2] = findViewById(R.id.btnC);
        btns[3] = findViewById(R.id.btnD);
        btns[4] = findViewById(R.id.btnE);
        btns[5] = findViewById(R.id.btnF);
        btns[6] = findViewById(R.id.btnG);
        btns[7] = findViewById(R.id.btnH);
        btns[8] = findViewById(R.id.btnI);
        btns[9] = findViewById(R.id.btnJ);
        btns[10] = findViewById(R.id.btnK);
        btns[11] = findViewById(R.id.btnL);
        btns[12] = findViewById(R.id.btnM);
        btns[13] = findViewById(R.id.btnN);
        btns[14] = findViewById(R.id.btnO);
        btns[15] = findViewById(R.id.btnP);
        btns[16] = findViewById(R.id.btnQ);
        btns[17] = findViewById(R.id.btnR);
        btns[18] = findViewById(R.id.btnS);
        btns[19] = findViewById(R.id.btnT);
        btns[20] = findViewById(R.id.btnU);
        btns[21] = findViewById(R.id.btnV);
        btns[22] = findViewById(R.id.btnW);
        btns[23] = findViewById(R.id.btnX);
        btns[24] = findViewById(R.id.btnY);
        btns[25] = findViewById(R.id.btnZ);

        //bind the onClick function to btns A-Z instead of using default onclick listeners
        for (int i = 0; i < 26; i++)
            btns[i].setOnClickListener(this);


        txtAnswers[0] = findViewById(R.id.txtQ);
        txtAnswers[1] = findViewById(R.id.txtU);
        txtAnswers[2] = findViewById(R.id.txtI);
        txtAnswers[3] = findViewById(R.id.txtZ);
        txtAnswers[4] = findViewById(R.id.txtL);
        txtAnswers[5] = findViewById(R.id.txtE);
        txtAnswers[6] = findViewById(R.id.txtT);

        btnHint = findViewById(R.id.btnHint);
        lblHint = findViewById(R.id.lblHint);
        imgViewResult = findViewById(R.id.imgViewResult);

        btnReset = findViewById(R.id.btnReset);
        //hint button functionality



        btnHint.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                hintCount++;
                game.incrementIncorrectAttempts();
                doHint();
            }
        });





        //reset the game
        btnReset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                game = new gameRun();
                hintCount = 0; //reset hint count
                btnHint.setClickable(true);
                lblHint.setText("");
                for(int j = 0;j<txtAnswers.length;j++)
                    txtAnswers[j].setText("");

                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman1));
            }
        });
    }


    //triggers when user clicks buttons A-Z
    @Override
    public void onClick(View v) {
        String strId = "";

        //find the letter of the button that user clicked
        for (int i = 0; i < 26; i++) {
            if (btns[i].getId() == v.getId()) {
                //strId means the letter the user clicked
                strId = String.valueOf(Character.toChars(97 + i));
                break;
            }
        }

        //result = true means the user pressed the correct letter and vice versa
        result = game.playerInput(strId);

        //change the image of the hangman according to incorrectAttempts
        changeImg(game);

        //check if the user input the correct letter and show on the txtAnswers
        checkIfCorrect(game);

        //check if the user win the game
        if(game.getIsWin()){
            Toast.makeText(getApplicationContext(), "Congrats! You win!", Toast.LENGTH_SHORT).show();
        }
        //check if the user lose the game
        else if(game.getIncorrectAttempts() == txtAnswers.length-1){
            Toast.makeText(getApplicationContext(), "Oops! You have lost!", Toast.LENGTH_SHORT).show();
        }
        //if the user get the correct letter but not win the game yet
        else if(result){
            Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_SHORT).show();
        }
        //if the user get the wrong letter
        else{
            Toast.makeText(getApplicationContext(), "Wrong!", Toast.LENGTH_SHORT).show();
        }
    }

    //check and show the letters on the txtAnswers
    private void checkIfCorrect(gameRun g){
        boolean[] checkcorrect = g.getArray();
        //0: q ; 1: u ; 2: i ; 3: z ; 4: l ; 5: e; 6:t
        String strAnswer = "quizlet";
        for(int i = 0;i<checkcorrect.length;i++){
            if(checkcorrect[i]){
                txtAnswers[i].setText(String.valueOf(strAnswer.charAt(i)));
            }
        }

    }

    //change the hangman image according to incorrectAttempts
    private void changeImg(gameRun g) {
        switch (g.getIncorrectAttempts()) {
            case 1:
                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman2));
                break;
            case 2:
                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman3));
                break;
            case 3:
                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman4));
                break;
            case 4:
                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman5));
                break;
            case 5:
                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman6));
                break;
            case 6:
                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman7));
                break;
            default:
                imgViewResult.setImageDrawable(getResources().getDrawable(R.drawable.hangman1));
                break;
        }
    }
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("gameRun", game);
        outState.putInt("hintCount",hintCount);
        for(int i = 0; i < txtAnswers.length; i++){
            outState.putString("txt"+i, txtAnswers[i].getText().toString());
        }






    }
    protected void onRestoreInstanceState(Bundle outState) {
        super.onRestoreInstanceState(outState);
        game = outState.getParcelable("gameRun");
        changeImg(game);
        hintCount = outState.getInt("hintCount");
        doHint();

        for(int i = 0; i < txtAnswers.length; i++){
            String output = outState.getString("txt"+i);
            txtAnswers[i].setText(output);
        }

    }

}
