package com.example.w4_p5;
import android.os.Parcelable;
import android.os.Parcel;
public class gameRun implements Parcelable {
    final static String gameWord = "quizlet"; //Hangman game word
    private boolean[] checkForWin; //array to keep track of words
    boolean[] trueArray;
    private boolean isWin; //check if player wins or loses
    private int incorrectAttempts;
    private int mData;


    public gameRun() { //game initializer
        checkForWin = new boolean[gameWord.length()];
        isWin = false;
        incorrectAttempts = 0;
        trueArray = new boolean[gameWord.length()];
        for (int i = 0; i < gameWord.length(); i++) {
            trueArray[i] = true;
        }
    }

    public boolean getIsWin() { //if isWin equal true then player has won
        return isWin;
    }

    public int getIncorrectAttempts() { //return incorrect attempts
        return incorrectAttempts;
    }

    public void incrementIncorrectAttempts() {
        incorrectAttempts++;
    }

    public boolean[] getArray() { //return's the true Array
        return checkForWin;
    }

    public void checkIfWin() { //checks for win condition
        for(int i = 0;i<checkForWin.length;i++){
            if (!checkForWin[i]){
                isWin = false;
                return;
            }
        }
        isWin = true;
    }

    public boolean playerInput(String input) {
        if (gameWord.contains(input)) { //if correct button selected then update array to true
            int index = gameWord.indexOf(input);
            checkForWin[index] = true;
            checkIfWin(); //if win, changes win boolean to true
            return true;
        } else { //return false if incorrect input
            incorrectAttempts++; //within controller, check for number of attempts
            return false;
        }
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        gameRun r = new gameRun();

    }
    //parceable interface implementation

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(mData);
    }

    public static final Parcelable.Creator<gameRun> CREATOR
            = new Parcelable.Creator<gameRun>() {
        public gameRun createFromParcel(Parcel in) {
            return new gameRun(in);
        }

        public gameRun[] newArray(int size) {
            return new gameRun[size];
        }
    };

    private gameRun(Parcel in) {
        mData = in.readInt();
    }


}